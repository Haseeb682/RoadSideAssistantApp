package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.roadsideapp.adapters.myadapter;
import com.example.roadsideapp.models.model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Breakdownproviderlist extends AppCompatActivity {
RecyclerView breakdowmrecyclerview;
myadapter breakdownadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breakdownproviderlist);
    breakdowmrecyclerview=findViewById(R.id.breaddownrecview);
    breakdowmrecyclerview.setLayoutManager(new LinearLayoutManager(Breakdownproviderlist.this));



        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Users")
                                        .child("locked")
                                , model.class)
                        .build();

        breakdownadapter=new myadapter(options);
        breakdowmrecyclerview.setAdapter(breakdownadapter);


    }
    @Override
    protected void onStart() {
        super.onStart();
        breakdownadapter.startListening();
    }

}