package com.example.roadsideapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignupScreen extends AppCompatActivity {
    EditText registername, registerphone, registeremail, registerpass, registercnfrmpass;
    AppCompatButton registerbutton;
    TextView signuptv;
    String regname;
    String regphone;
    String regemail;
    String regpassword;
    String regconfirmpassword;

    ProgressDialog progressDialog;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

FirebaseAuth firebaseAuth;
FirebaseUser firebaseUser;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_screen);


        registername = findViewById(R.id.usernameregistration);
        registerphone = findViewById(R.id.registrationphonenumber);
        registeremail = findViewById(R.id.registrationemail);
        registerpass = findViewById(R.id.registrationpassword);
        registercnfrmpass = findViewById(R.id.registrationconfirmpassword);
        registerbutton = findViewById(R.id.register);

        signuptv=findViewById(R.id.signuplogintext);
        progressDialog=new ProgressDialog(this);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();

        signuptv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignupScreen.this,LoginScreen.class));
            }
        });

        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PerformAuthentication();
            }
        });

    }
    private void PerformAuthentication() {
        regname=registername.getText().toString();
        regphone=registerphone.getText().toString();
        regemail=registeremail.getText().toString();
        regpassword=registerpass.getText().toString();
        regconfirmpassword=registercnfrmpass.getText().toString();


        if(regphone.length()<11){
            registerphone.setError("ENter correct phone number");
        } else if (!regemail.matches(emailPattern)){
            registeremail.setError("Invalid Email");
        }
        else if (regpassword.isEmpty()||regpassword.length()<6){
            registerpass.setError("Enter valid password");
        }else if (!regpassword.matches(regconfirmpassword)){
            registercnfrmpass.setError("Password does not match");
        }
        else {
            progressDialog.setMessage("Please wait while registration");
            progressDialog.setTitle("Registration. . .");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

            firebaseAuth.createUserWithEmailAndPassword(regemail,regpassword)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){

                                Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                                Users users=new Users(regname,regemail,regphone,regpassword,regconfirmpassword);
                                databaseReference.child("Users").child("user").child(firebaseUser.getUid()).setValue(users);
                                progressDialog.dismiss();
                                SendUsertoLoginActivity();
                            }else {
                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), ""+task.getException(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }
    }

    private void SendUsertoLoginActivity() {
        Intent intent=new Intent(SignupScreen.this,LoginScreen.class);
        startActivity(intent);
    }

    }
