package com.example.roadsideapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ServiceproviderLocation extends AppCompatActivity implements OnMapReadyCallback {
FloatingActionButton SPfloatbutton;
AppCompatButton SPconfirmlocationbtn;

    Location currlocations;
    private final int reques_code = 101;
    Marker mCurrLocationMarker;
    private GoogleMap mMap;

    SupportMapFragment SPsmf;
    FusedLocationProviderClient SPclient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_serviceprovider_location);

        //   smf= (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.serviceprovidermap);
        SPclient= LocationServices.getFusedLocationProviderClient(this);

        SPfloatbutton=findViewById(R.id.serviceproviderocationbutton);
      SPconfirmlocationbtn=findViewById(R.id.serviceproviderconfirmlocationbutton);

      SPconfirmlocationbtn.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              locationconfirmed();

          }
      });
      SPfloatbutton.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              final LocationManager manager = (LocationManager) getSystemService(getApplicationContext().LOCATION_SERVICE);

              if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                  buildAlertMessageNoGps();
              } else {
                  fetchlastlocation();
              }

          }
      });

    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        buildAlertMessageNoGps();

                        // dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
    private void locationconfirmed() {
        if (currlocations!=null){
            Toast.makeText(getApplicationContext(), "Location Confirmed", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(ServiceproviderLocation.this,SuggestionScreen.class));
        }
        else {
            Toast.makeText(getApplicationContext(), "Location is not selected", Toast.LENGTH_SHORT).show();
        }
    }



    private void fetchlastlocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission
                        (this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION},reques_code);
            return;
        }

        Task<Location> engineoiltask = SPclient.getLastLocation();
        engineoiltask.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location!=null){
                    currlocations=location;
                    Toast.makeText(getApplicationContext(),currlocations.getLatitude()
                            +""+currlocations.getLongitude(),Toast.LENGTH_SHORT).show();
                    SupportMapFragment supportMapFragment=(SupportMapFragment) getSupportFragmentManager().
                            findFragmentById(R.id.needhelpmap);
                    supportMapFragment.getMapAsync(ServiceproviderLocation.this);
                }
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case reques_code:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchlastlocation();
                }
                break;
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng=new LatLng(currlocations.getLatitude(),currlocations.getLongitude());
        MarkerOptions markerOptions=new MarkerOptions().position(latLng).title("I am here");
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
        googleMap.addMarker(markerOptions);
    }
/*
    public void broadcastIntent() {
        registerReceiver(MyReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(MyReceiver);
    }*/

    @Override
    public void onBackPressed() {

        this.finish();
        //   startActivity(new Intent(EngineLocation.this,ThirdActivity.class));
    }

}