package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.roadsideapp.adapters.myadapter;
import com.example.roadsideapp.models.model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Lockedproviderlist extends AppCompatActivity {
RecyclerView locrecyclerview;
myadapter lockadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lockedproviderlist);
       locrecyclerview=findViewById(R.id.lockedrecview);
       locrecyclerview.setLayoutManager(new LinearLayoutManager(Lockedproviderlist.this));

        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Users")
                                        .child("locked")
                                , model.class)
                        .build();

        lockadapter=new myadapter(options);
        locrecyclerview.setAdapter(lockadapter);

    }
    @Override
    protected void onStart() {
        super.onStart();
        lockadapter.startListening();
    }

}