package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.roadsideapp.adapters.myadapter;
import com.example.roadsideapp.models.model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Towingproviderlist extends AppCompatActivity {
RecyclerView towingreccylerview;
myadapter towingadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_towingproviderlist);
    towingreccylerview=findViewById(R.id.towingrecview);
    towingreccylerview.setLayoutManager(new LinearLayoutManager(Towingproviderlist.this));


        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Users")
                                        .child("locked")
                                , model.class)
                        .build();

        towingadapter=new myadapter(options);
        towingreccylerview.setAdapter(towingadapter);

    }
    @Override
    protected void onStart() {
        super.onStart();
        towingadapter.startListening();
    }

}