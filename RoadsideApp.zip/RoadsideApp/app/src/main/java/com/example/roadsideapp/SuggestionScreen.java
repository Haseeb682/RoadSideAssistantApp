package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SuggestionScreen extends AppCompatActivity {
    TextView textViewgethelp,textviewserviceprovider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestion_screen);

        textViewgethelp=findViewById(R.id.gethelp);
        textviewserviceprovider=findViewById(R.id.serviceprovider);

        textViewgethelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SuggestionScreen.this,NeedHelpLocation.class));
            }
        });
        textviewserviceprovider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SuggestionScreen.this,ServiceproviderLocation.class);
                startActivity(intent);
            }
        });
    }

}
