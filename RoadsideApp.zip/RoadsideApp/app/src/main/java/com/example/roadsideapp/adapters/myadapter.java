package com.example.roadsideapp.adapters;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.roadsideapp.R;
import com.example.roadsideapp.models.model;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class myadapter extends FirebaseRecyclerAdapter<model,myadapter.myviewholder> {
    String one;

    public myadapter(@NonNull FirebaseRecyclerOptions<model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull model model) {
        holder.name.setText(model.getName());
        holder.phone.setText(model.getPhone());
        holder.loca.setText(model.getLocation());
        holder.serve.setText(model.getService());

        one= model.getPhone();

        holder.phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



 // view.getContext().startActivity(new Intent(view.getContext(),Carlockedproviderlist.class));


            view.getContext().startActivity(new Intent(Intent.ACTION_DIAL,
                      Uri.fromParts("tel",one,null)));


                /*                String phone = "03011234567";
                view.getContext().startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null)));
*/

                //     view.getContext().startActivity(new Intent(view.getContext(),MainActivity2.class));
            }
        });
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow, parent, false);
        return new myviewholder(view);
    }



    class myviewholder extends RecyclerView.ViewHolder {
        TextView name, phone, loca, serve;

        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.personname);
            phone = (TextView) itemView.findViewById(R.id.personphone);
            loca = (TextView) itemView.findViewById(R.id.personlocation);
            serve = (TextView) itemView.findViewById(R.id.personservice);
        }
    }

}




