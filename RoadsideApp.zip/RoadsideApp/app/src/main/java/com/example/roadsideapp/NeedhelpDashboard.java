package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class NeedhelpDashboard extends AppCompatActivity {
    CardView fuel,engineoil,towing,breakdown,lock,engineheat,tire,battery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_needhelp_dashboard);

        fuel=findViewById(R.id.lowfuelcard);
        engineoil=findViewById(R.id.engineoilcard);
        towing=findViewById(R.id.Towingcard);
        breakdown=findViewById(R.id.Breakdowncard);
        lock=findViewById(R.id.lockedcard);
        engineheat=findViewById(R.id.Enginecard);
        tire=findViewById(R.id.flattiercard);
        battery=findViewById(R.id.batterydiedcard);

        fuel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(NeedhelpDashboard.this,Lowfuelproviderslist.class));
            }
        });

        engineoil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              startActivity(new Intent(NeedhelpDashboard.this,Engineoilproviderlist.class));
            }
        });

        towing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
           startActivity(new Intent(NeedhelpDashboard.this,Towingproviderlist.class));
            }
        });

        breakdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(NeedhelpDashboard.this,Breakdownproviderlist.class));
            }
        });

        engineheat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
           startActivity(new Intent(NeedhelpDashboard.this,Engineheatproviderslist.class));
            }
        });

        tire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(NeedhelpDashboard.this,Flattyreproviderlist.class));

            }
        });

        battery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(NeedhelpDashboard.this,Batterydeadproviderlist.class));
            }
        });


        lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NeedhelpDashboard.this,Lockedproviderlist.class));

            }
        });


    }
}