package com.example.roadsideapp.models;

public class model {
    String name,phone,location,service;

    public model() {
    }

    public model(String name, String phone, String location, String service) {
        this.name = name;
        this.phone = phone;
        this.location = location;
        this.service = service;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }


}
