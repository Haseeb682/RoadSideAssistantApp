package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.roadsideapp.adapters.myadapter;
import com.example.roadsideapp.models.model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Lowfuelproviderslist extends AppCompatActivity {
RecyclerView view;
myadapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lowfuelproviderslist);
        view=findViewById(R.id.lowfuelrecview);

        view.setLayoutManager(new LinearLayoutManager(Lowfuelproviderslist.this));

        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Users")
                                        .child("locked")
                                , model.class)
                        .build();

        adapter=new myadapter(options);
        view.setAdapter(adapter);

    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

}