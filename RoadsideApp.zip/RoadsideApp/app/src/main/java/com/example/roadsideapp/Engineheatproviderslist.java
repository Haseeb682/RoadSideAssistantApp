package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.roadsideapp.adapters.myadapter;
import com.example.roadsideapp.models.model;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Engineheatproviderslist extends AppCompatActivity {
RecyclerView engineheatrecyclerview;
myadapter engineheatadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_engineheatproviderslist);
    engineheatrecyclerview=findViewById(R.id.engineheatrecview);
    engineheatrecyclerview.setLayoutManager(new LinearLayoutManager(Engineheatproviderslist.this));


        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Users")
                                        .child("locked")
                                , model.class)
                        .build();

        engineheatadapter=new myadapter(options);
        engineheatrecyclerview.setAdapter(engineheatadapter);


    }
    @Override
    protected void onStart() {
        super.onStart();
        engineheatadapter.startListening();
    }

}