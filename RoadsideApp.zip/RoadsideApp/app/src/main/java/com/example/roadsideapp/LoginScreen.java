package com.example.roadsideapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class LoginScreen extends AppCompatActivity {
    EditText emails,passwords;
    Button loginbutton;
    TextView loginscreentv;
    ProgressDialog progressDialog;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        emails=findViewById(R.id.loginemail);
        passwords=findViewById(R.id.loginpasswords);
        loginbutton=findViewById(R.id.login);
        progressDialog=new ProgressDialog(this);


        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("User");
        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                performlogin();
            }
        });




    }


    private void performlogin() {
        String loginemail = emails.getText().toString();
        String loginpassword = passwords.getText().toString();
        if (!loginemail.matches(emailPattern)) {
            emails.setError("Invalid Email");
        } else if (loginpassword.isEmpty() || loginpassword.length() < 6) {
            passwords.setError("Enter valid password");
        } else {
            progressDialog.setMessage("Please wait while Login");
            progressDialog.setTitle("Login. . .");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();



            firebaseAuth.signInWithEmailAndPassword(loginemail,loginpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        progressDialog.dismiss();
                        sendusertotirdActivity();
                        Toast.makeText(LoginScreen.this, "Login Successfull", Toast.LENGTH_SHORT).show();

                    }else {
                        progressDialog.dismiss();
                        Toast.makeText(LoginScreen.this, ""+task.getException(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }
    private void sendusertotirdActivity() {
        Intent intent=new Intent(LoginScreen.this,MainActivity.class);
        startActivity(intent);

    }

}
            /*/
            Query usercheck = databaseReference.orderByChild(firebaseUser.getUid());
            usercheck.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        progressDialog.dismiss();
                        sendusertotirdActivity();
                        Toast.makeText(getApplicationContext(), "Login Sucessfuly", Toast.LENGTH_SHORT).show();
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

*/