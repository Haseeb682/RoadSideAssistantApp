package com.example.roadsideapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

public class MainActivity extends AppCompatActivity {
LottieAnimationView lottieAnimationView;
    ImageView imageView;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

/*

        lottieAnimationView=findViewById(R.id.caranimation);
        textView=findViewById(R.id.textviewsplash);
        imageView=findViewById(R.id.iamgeviews);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        lottieAnimationView.animate().translationX(-1400).setDuration(2000).setStartDelay(2000);
        imageView.animate().translationX(-1400).setDuration(2000).setStartDelay(2000);
        textView.animate().translationX(-1400).setDuration(2000).setStartDelay(2000);
*/
    /*    new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashScreen.this,SignupScreen.class);
                startActivity(intent);
            }
        },3430);
*/
    }
}


